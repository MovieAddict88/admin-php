<?php
define('DB_SERVER', 'sql306.infinityfree.com');
define('DB_USERNAME', 'if0_39989224');
define('DB_PASSWORD', 'U1At0hgKptnk');
define('DB_NAME', 'if0_39989224_playlist');

// TMDB API Keys
define('TMDB_API_KEYS', [
    'ec926176bf467b3f7735e3154238c161',
    'bb51e18edb221e87a05f90c2eb456069'
]);
?>
